/* 

Raymond Hear (GWID: G26215348)
Introduction to Computer Systems
CSCI 6011
Professor Anrieta Draganova
2021 April 1

COMPLETE THE FOLLOWING TASK -------------------------------------------------------------

Create the so-called dynamic array to allow the elements in the array to grow as required.
After creating the dynamic array, resize it and write a C/C++ program. Compile and run your
program.

Upon completion of the C program, submit your source code for feedback and grading to
anri@gwu.edu by 23:59 ET.

*/

#include <iostream>
using namespace std;

// DEFINE STACK ------------------------------------------------------------------------
#define SIZE 8
int stackTop = -1, stackLen = 0;

// DEFINE FUNCTIONS ---------------------------------------------------------------------
int *makeStack(int *item)
{

    int *stack = new int[stackLen + SIZE];

    for (int i = 0; i < stackLen; i++)
        stack[i] = item[i];

    stackLen += SIZE;
    return stack;
}

// Define pop
void popStack(int *item)
{
    stackTop--;
}

// Define push
int *pushStack(int *item, int element)
{
    if (stackTop == stackLen - 1)
        item = makeStack(item);

    item[++stackTop] = element;
    return item;
}

// Log output
void printStack(int *item)
{
    if (stackTop == -1)
        cout << "EMPTY STACK" << endl;
    else
    {
        cout << "> ";
        for (int i = 0; i <= stackTop; i++)
            cout << item[i] << " ";
        cout << endl;
    }
}

// DRIVER --------------------------------------------------------------------------------
int main()
{
    int *item = makeStack(item);

    // Grow stack from 0 to 9
    item = pushStack(item, 0);
    printStack(item);
    item = pushStack(item, 1);
    printStack(item);
    item = pushStack(item, 2);
    printStack(item);
    item = pushStack(item, 3);
    printStack(item);
    item = pushStack(item, 4);
    printStack(item);
    item = pushStack(item, 5);
    printStack(item);
    item = pushStack(item, 6);
    printStack(item);
    item = pushStack(item, 7);
    printStack(item);
    item = pushStack(item, 8);
    printStack(item);
    item = pushStack(item, 9);
    printStack(item);

    // Reduce stack from 9 to 0
    popStack(item);
    printStack(item);
    popStack(item);
    printStack(item);
    popStack(item);
    printStack(item);
    popStack(item);
    printStack(item);
    popStack(item);
    printStack(item);
    popStack(item);
    printStack(item);
    popStack(item);
    printStack(item);
    popStack(item);
    printStack(item);
    popStack(item);
    printStack(item);

    return 0;

    /*
        > 0 
        > 0 1 
        > 0 1 2 
        > 0 1 2 3 
        > 0 1 2 3 4 
        > 0 1 2 3 4 5 
        > 0 1 2 3 4 5 6 
        > 0 1 2 3 4 5 6 7 
        > 0 1 2 3 4 5 6 7 8 
        > 0 1 2 3 4 5 6 7 8 9 
        > 0 1 2 3 4 5 6 7 8 
        > 0 1 2 3 4 5 6 7 
        > 0 1 2 3 4 5 6 
        > 0 1 2 3 4 5 
        > 0 1 2 3 4 
        > 0 1 2 3 
        > 0 1 2 
        > 0 1 
        > 0 
    */
}